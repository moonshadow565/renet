#include <stdlib.h>
#include <stdio.h>


typedef struct _swag {
    int x;
} swag;

static swag* ptr = 0;

extern swag* swag_create(void) {
    swag* s = malloc(sizeof(swag));
    s->x = 1337;
    ptr = s;
    return s;
}

extern void swag_print(const swag* s) {
    printf("Swag is: %u!\n", s->x);
}

extern void swag_print_last() {
    printf("Last Swag is: %u!\n", ptr->x);
}